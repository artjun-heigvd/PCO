#ifndef PCOBARRIER_H
#define PCOBARRIER_H

class PcoBarrier
{

public:
    PcoBarrier(unsigned int nbToWait)
    {
    }

    ~PcoBarrier()
    {
    }

    void wait()
    {
    }
};

#endif // PCOBARRIER_H
